=== ScrollFlow ===
Contributors: rakibhasan
Tags: scroll to top, progress, button, customization
Requires at least: 5.8
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPL-2.0-or-later

Scroll-to-top button with HEX color controls, SVG icons, and progress ring.

== Installation ==
1. Upload scrollflow.zip via Plugins > Add New Plugin > Upload Plugin.
2. Activate the plugin.
3. Go to Settings > ScrollFlow.

== Developer ==
Rakib Hasan — https://codewithrakib.com
