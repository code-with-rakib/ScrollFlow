<?php
/**
 * Plugin Name: ScrollFlow
 * Plugin URI: https://codewithrakib.com
 * Description: A fixed-size scroll-to-top button with editable HEX colors, SVG icons, and circular reading progress.
 * Version: 1.0.0
 * Requires at least: 5.8
 * Requires PHP: 7.4
 * Author: Rakib Hasan
 * Author URI: https://codewithrakib.com
 * License: GPL-2.0-or-later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: scrollflow
 */

if (!defined('ABSPATH')) {
    exit;
}

final class ScrollFlow {
    const OPTION = 'scrollflow_options';
    const VERSION = '1.0.0';

    public function __construct() {
        add_action('admin_menu', array($this, 'admin_menu'));
        add_action('admin_init', array($this, 'register_settings'));
        add_action('admin_enqueue_scripts', array($this, 'admin_assets'));
        add_action('wp_enqueue_scripts', array($this, 'enqueue_frontend'));
        add_action('wp_footer', array($this, 'render_button'));
        add_filter('plugin_action_links_' . plugin_basename(__FILE__), array($this, 'settings_link'));
    }

    private function defaults() {
        return array(
            'brand' => '#0F5938',
            'track' => '#E1ECE5',
            'icon_color' => '#FFFFFF',
            'icon' => 'chevron',
            'bottom' => 24,
            'right' => 24,
            'mobile' => 1,
            'show_progress' => 1,
            'show_credit' => 1,
        );
    }

    private function options() {
        return wp_parse_args(get_option(self::OPTION, array()), $this->defaults());
    }

    public function admin_menu() {
        add_options_page(
            'ScrollFlow',
            'ScrollFlow',
            'manage_options',
            'scrollflow',
            array($this, 'settings_page')
        );
    }

    public function register_settings() {
        register_setting(
            'scrollflow_settings_group',
            self::OPTION,
            array('sanitize_callback' => array($this, 'sanitize_options'))
        );
    }

    public function admin_assets($hook) {
        if ('settings_page_scrollflow' !== $hook) {
            return;
        }

        wp_register_style('scrollflow-admin', false, array(), self::VERSION);
        wp_enqueue_style('scrollflow-admin');
        wp_add_inline_style(
            'scrollflow-admin',
            '.scrollflow-card{max-width:850px;background:#fff;border:1px solid #dcdcde;border-radius:10px;padding:20px 24px;margin-top:18px}.scrollflow-card h2{margin-top:0}.scrollflow-card .form-table th{width:260px}.scrollflow-color-row{display:flex;align-items:center;gap:10px;flex-wrap:wrap}.scrollflow-color-row input[type=color]{width:44px;height:36px;padding:2px}.scrollflow-color-row input[type=text]{width:125px;font-family:monospace;text-transform:uppercase}.scrollflow-help{display:block;color:#646970;font-size:12px;margin-top:5px}'
        );

        wp_register_script('scrollflow-admin', false, array(), self::VERSION, true);
        wp_enqueue_script('scrollflow-admin');
        wp_add_inline_script(
            'scrollflow-admin',
            "document.addEventListener('DOMContentLoaded',function(){document.querySelectorAll('.scrollflow-color-row').forEach(function(row){var picker=row.querySelector('input[type=color]');var hex=row.querySelector('input[type=text]');if(!picker||!hex)return;picker.addEventListener('input',function(){hex.value=picker.value.toUpperCase();hex.setCustomValidity('');});hex.addEventListener('input',function(){var v=hex.value.trim();if(/^#([0-9a-fA-F]{6})$/.test(v)){picker.value=v;hex.setCustomValidity('');}else{hex.setCustomValidity('Enter a valid 6-digit HEX color, for example #0F5938.');}});hex.addEventListener('blur',function(){hex.value=hex.value.toUpperCase();});});});"
        );
    }

    public function sanitize_options($input) {
        $defaults = $this->defaults();
        $out = array();

        foreach (array('brand', 'track', 'icon_color') as $key) {
            $raw = isset($input[$key]) ? trim(sanitize_text_field($input[$key])) : $defaults[$key];

            if (preg_match('/^#(?:[0-9a-fA-F]{3}|[0-9a-fA-F]{6})$/', $raw)) {
                $out[$key] = sanitize_hex_color($raw);
            } else {
                $out[$key] = $defaults[$key];
            }

            if (!$out[$key]) {
                $out[$key] = $defaults[$key];
            }
        }

        $icons = array('chevron', 'arrow', 'caret', 'long-arrow');
        $out['icon'] = isset($input['icon']) && in_array($input['icon'], $icons, true)
            ? $input['icon']
            : $defaults['icon'];

        foreach (array('bottom', 'right') as $key) {
            $value = isset($input[$key]) ? absint($input[$key]) : $defaults[$key];
            $out[$key] = min(200, max(8, $value));
        }

        foreach (array('mobile', 'show_progress', 'show_credit') as $key) {
            $out[$key] = !empty($input[$key]) ? 1 : 0;
        }

        return $out;
    }

    public function settings_link($links) {
        array_unshift(
            $links,
            '<a href="' . esc_url(admin_url('options-general.php?page=scrollflow')) . '">Settings</a>'
        );
        return $links;
    }

    private function color_field($key, $label, $value) {
        $id = 'scrollflow-' . $key;
        echo '<tr><th scope="row"><label for="' . esc_attr($id) . '">' . esc_html($label) . '</label></th><td>';
        echo '<div class="scrollflow-color-row">';
        echo '<input type="color" aria-label="' . esc_attr($label) . ' color picker" value="' . esc_attr($value) . '">';
        echo '<input id="' . esc_attr($id) . '" type="text" maxlength="7" pattern="^#[0-9A-Fa-f]{6}$" name="' . esc_attr(self::OPTION) . '[' . esc_attr($key) . ']" value="' . esc_attr(strtoupper($value)) . '" required>';
        echo '</div><span class="scrollflow-help">HEX color, e.g. #0F5938</span></td></tr>';
    }

    public function settings_page() {
        if (!current_user_can('manage_options')) {
            return;
        }

        $o = $this->options();
        ?>
        <div class="wrap">
            <h1>ScrollFlow</h1>
            <p>Customize the scroll-to-top button. Use the color picker or enter a HEX color code directly.</p>
            <div class="scrollflow-card">
                <form method="post" action="options.php">
                    <?php settings_fields('scrollflow_settings_group'); ?>
                    <h2>Colors</h2>
                    <table class="form-table" role="presentation"><tbody>
                        <?php
                        $this->color_field('brand', 'Button background color', $o['brand']);
                        $this->color_field('track', 'Progress ring background', $o['track']);
                        $this->color_field('icon_color', 'Arrow icon color', $o['icon_color']);
                        ?>
                    </tbody></table>
                    <h2>Icon and position</h2>
                    <table class="form-table" role="presentation"><tbody>
                        <tr>
                            <th scope="row"><label for="scrollflow-icon">Arrow icon</label></th>
                            <td><select id="scrollflow-icon" name="<?php echo esc_attr(self::OPTION); ?>[icon]">
                                <option value="chevron" <?php selected($o['icon'], 'chevron'); ?>>Chevron</option>
                                <option value="arrow" <?php selected($o['icon'], 'arrow'); ?>>Arrow</option>
                                <option value="caret" <?php selected($o['icon'], 'caret'); ?>>Caret</option>
                                <option value="long-arrow" <?php selected($o['icon'], 'long-arrow'); ?>>Long arrow</option>
                            </select></td>
                        </tr>
                        <tr><th scope="row"><label for="scrollflow-bottom">Distance from bottom (px)</label></th><td><input id="scrollflow-bottom" type="number" min="8" max="200" name="<?php echo esc_attr(self::OPTION); ?>[bottom]" value="<?php echo esc_attr($o['bottom']); ?>"></td></tr>
                        <tr><th scope="row"><label for="scrollflow-right">Distance from right (px)</label></th><td><input id="scrollflow-right" type="number" min="8" max="200" name="<?php echo esc_attr(self::OPTION); ?>[right]" value="<?php echo esc_attr($o['right']); ?>"></td></tr>
                        <tr><th scope="row">Display options</th><td>
                            <label><input type="checkbox" name="<?php echo esc_attr(self::OPTION); ?>[show_progress]" value="1" <?php checked($o['show_progress'], 1); ?>> Show circular scroll progress</label><br>
                            <label><input type="checkbox" name="<?php echo esc_attr(self::OPTION); ?>[mobile]" value="1" <?php checked($o['mobile'], 1); ?>> Show on mobile</label><br>
                            <label><input type="checkbox" name="<?php echo esc_attr(self::OPTION); ?>[show_credit]" value="1" <?php checked($o['show_credit'], 1); ?>> Show developer credit in tooltip</label>
                        </td></tr>
                    </tbody></table>
                    <?php submit_button('Save Settings'); ?>
                </form>
            </div>
            <p><strong>Developer:</strong> Rakib Hasan · <a href="https://codewithrakib.com" target="_blank" rel="noopener noreferrer">codewithrakib.com</a></p>
        </div>
        <?php
    }

    public function enqueue_frontend() {
        if (is_admin()) {
            return;
        }

        $o = $this->options();
        $css = "
        html body button.scrollflow-scroll-top,html body .scrollflow-scroll-top{all:initial!important;box-sizing:border-box!important;position:fixed!important;inset:auto " . (int) $o['right'] . "px " . (int) $o['bottom'] . "px auto!important;width:48px!important;min-width:48px!important;max-width:48px!important;height:48px!important;min-height:48px!important;max-height:48px!important;margin:0!important;padding:0!important;border:0!important;border-radius:50%!important;display:flex!important;align-items:center!important;justify-content:center!important;float:none!important;line-height:1!important;text-align:center!important;text-decoration:none!important;cursor:pointer!important;z-index:999999!important;opacity:0!important;visibility:hidden!important;transform:translateY(12px)!important;transition:opacity .22s ease,visibility .22s ease,transform .22s ease!important;background:transparent!important;box-shadow:none!important;overflow:visible!important}
        html body button.scrollflow-scroll-top.show,html body .scrollflow-scroll-top.show,html body .elementor-editor-active .scrollflow-scroll-top{opacity:1!important;visibility:visible!important;transform:translateY(0)!important}
        html body button.scrollflow-scroll-top:hover,html body .scrollflow-scroll-top:hover{transform:translateY(-3px) scale(1.03)!important}
        html body button.scrollflow-scroll-top:focus-visible{outline:2px solid {$o['brand']}!important;outline-offset:3px!important}
        .scrollflow-scroll-top .scrollflow-progress-svg{position:absolute!important;inset:0!important;display:block!important;width:48px!important;height:48px!important;max-width:none!important;max-height:none!important;margin:0!important;padding:0!important;transform:rotate(-90deg)!important;pointer-events:none!important;overflow:visible!important}
        .scrollflow-scroll-top .scrollflow-progress-bg{fill:none!important;stroke:{$o['track']}!important;stroke-width:3!important}
        .scrollflow-scroll-top .scrollflow-progress-bar{fill:none!important;stroke:{$o['brand']}!important;stroke-width:3!important;stroke-linecap:round!important;stroke-dasharray:150.8!important;stroke-dashoffset:150.8;transition:stroke-dashoffset .1s linear!important}
        .scrollflow-scroll-top .scrollflow-icon-wrap{all:initial!important;box-sizing:border-box!important;position:relative!important;z-index:2!important;width:36px!important;min-width:36px!important;max-width:36px!important;height:36px!important;min-height:36px!important;max-height:36px!important;margin:0!important;padding:0!important;border:0!important;border-radius:50%!important;background:{$o['brand']}!important;color:{$o['icon_color']}!important;display:flex!important;align-items:center!important;justify-content:center!important;box-shadow:0 3px 10px rgba(15,89,56,.25)!important;line-height:1!important}
        .scrollflow-scroll-top .scrollflow-icon-wrap svg{display:block!important;width:18px!important;min-width:18px!important;max-width:18px!important;height:18px!important;min-height:18px!important;max-height:18px!important;margin:0!important;padding:0!important;fill:currentColor!important;stroke:none!important;overflow:visible!important}
        " . (empty($o['show_progress']) ? '.scrollflow-scroll-top .scrollflow-progress-svg{display:none!important}' : '') . "
        " . (empty($o['mobile']) ? '@media(max-width:768px){html body button.scrollflow-scroll-top,html body .scrollflow-scroll-top{display:none!important}}' : '') . "
        @media(prefers-reduced-motion:reduce){html body .scrollflow-scroll-top{transition:none!important}}
        ";

        wp_register_style('scrollflow-frontend', false, array(), self::VERSION);
        wp_enqueue_style('scrollflow-frontend');
        wp_add_inline_style('scrollflow-frontend', $css);

        wp_register_script('scrollflow-frontend', false, array(), self::VERSION, true);
        wp_enqueue_script('scrollflow-frontend');
        $js = "(function(){function init(){var btn=document.getElementById('scrollflowScrollTop');var bar=document.getElementById('scrollflowProgressBar');if(!btn)return;var c=150.8;function update(){var top=window.scrollY||document.documentElement.scrollTop||0;var doc=document.documentElement;var height=Math.max(0,(doc.scrollHeight||document.body.scrollHeight)-window.innerHeight);var p=height>0?Math.min(Math.max(top/height,0),1):0;btn.classList.toggle('show',top>50);if(bar)bar.style.strokeDashoffset=c-(p*c);}window.addEventListener('scroll',update,{passive:true});window.addEventListener('resize',update);btn.addEventListener('click',function(e){e.preventDefault();window.scrollTo({top:0,behavior:window.matchMedia('(prefers-reduced-motion: reduce)').matches?'auto':'smooth'});});update();}if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init);else init();})();";
        wp_add_inline_script('scrollflow-frontend', $js);
    }

    private function icon_path($icon) {
        switch ($icon) {
            case 'arrow':
                return '<path d="M12 4 4.5 11.5l1.8 1.8 4.4-4.4V20h2.6V8.9l4.4 4.4 1.8-1.8L12 4z"/>';
            case 'caret':
                return '<path d="m4 15 8-8 8 8z"/>';
            case 'long-arrow':
                return '<path d="M12 3 5 10h4v10h6V10h4z"/>';
            default:
                return '<path d="m12 8-6 6 1.41 1.41L12 10.83l4.59 4.58L18 14z"/>';
        }
    }

    public function render_button() {
        if (is_admin()) {
            return;
        }

        $o = $this->options();
        $title = !empty($o['show_credit'])
            ? 'Back to top — Developer by Rakib Hasan, codewithrakib.com'
            : 'Back to top';
        ?>
        <button type="button" class="scrollflow-scroll-top" id="scrollflowScrollTop" aria-label="<?php echo esc_attr($title); ?>" title="<?php echo esc_attr($title); ?>">
            <?php if (!empty($o['show_progress'])) : ?>
                <svg class="scrollflow-progress-svg" viewBox="0 0 54 54" aria-hidden="true" focusable="false">
                    <circle class="scrollflow-progress-bg" cx="27" cy="27" r="24"></circle>
                    <circle class="scrollflow-progress-bar" cx="27" cy="27" r="24" id="scrollflowProgressBar"></circle>
                </svg>
            <?php endif; ?>
            <span class="scrollflow-icon-wrap" aria-hidden="true"><svg viewBox="0 0 24 24" focusable="false"><?php echo $this->icon_path($o['icon']); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></svg></span>
        </button>
        <?php
    }
}

new ScrollFlow();
